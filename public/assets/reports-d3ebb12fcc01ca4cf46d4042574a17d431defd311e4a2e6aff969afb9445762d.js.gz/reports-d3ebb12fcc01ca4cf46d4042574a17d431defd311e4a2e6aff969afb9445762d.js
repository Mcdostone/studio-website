$(function() {  $
  $('#report_message').trigger('autoresize')
})
;
