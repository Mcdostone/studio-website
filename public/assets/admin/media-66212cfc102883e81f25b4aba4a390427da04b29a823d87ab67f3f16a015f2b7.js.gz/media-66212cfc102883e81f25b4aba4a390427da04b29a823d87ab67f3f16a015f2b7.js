$(function() {
	$('.chips').material_chip()
	$('select').material_select()
})
;
